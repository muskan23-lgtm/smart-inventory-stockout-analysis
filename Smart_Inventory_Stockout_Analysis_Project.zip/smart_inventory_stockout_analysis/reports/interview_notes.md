# Interview Notes: Smart Inventory & Stockout Analysis

## 30-second explanation
I built a Smart Inventory and Stockout Analysis project using Python, Pandas, SQL, and Streamlit. It combines daily sales, product information, and current stock to identify products that may run out of stock. It calculates average daily demand, estimates days of stock remaining, and suggests reorder quantities based on supplier lead time and a target stock-coverage period. The dashboard helps users prioritize inventory decisions.

## Key business definitions
- Average daily demand = total units sold / number of days in the sales dataset.
- Lead-time demand = average daily demand × supplier lead time.
- Reorder point = lead-time demand + safety stock.
- Days of stock remaining = current stock / average daily demand.
- Suggested reorder quantity = max(0, average daily demand × target coverage days − current stock).

## Why use these tools?
- Python/Pandas: load, clean, combine, and analyze CSV data.
- SQL: answer structured questions using joins, grouping, and filtering.
- Streamlit: create an interactive dashboard quickly with Python.
- Plotly: display category and product comparisons.

## Limitations to acknowledge
- The included data is synthetic.
- The project uses simple average demand rather than a trained forecasting model.
- Safety stock is a demonstration assumption (20% of lead-time demand).
- Real recommendations should account for seasonality, demand variability, supplier reliability, minimum order quantities, storage capacity, budget, and service-level targets.

## Likely questions
**Q: How do you detect stockout risk?**
A: I compare current stock with the estimated reorder point. If stock is at or below the reorder point, I flag the item for review.

**Q: Is every flag an actual stockout?**
A: No. It is an early-warning indicator based on assumptions. Actual stockouts depend on future demand and replenishment timing.

**Q: How could you improve the project?**
A: Add demand forecasting, back-test it against a baseline, use variable safety stock based on demand variability and service level, and incorporate supplier delivery history.
