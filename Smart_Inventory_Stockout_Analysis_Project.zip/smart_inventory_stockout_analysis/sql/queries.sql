-- SQLite examples for Smart Inventory & Stockout Analysis.
-- Run after importing data/products.csv, data/daily_sales.csv and data/inventory.csv
-- into tables named products, daily_sales, and inventory.

-- 1. Total units sold by product
SELECT p.product_name, p.category, SUM(s.quantity_sold) AS total_units_sold
FROM products p
JOIN daily_sales s ON s.product_id = p.product_id
GROUP BY p.product_id, p.product_name, p.category
ORDER BY total_units_sold DESC;

-- 2. Monthly demand by product
SELECT strftime('%Y-%m', s.date) AS month,
       p.product_name,
       SUM(s.quantity_sold) AS monthly_units
FROM daily_sales s
JOIN products p ON p.product_id = s.product_id
GROUP BY month, p.product_id, p.product_name
ORDER BY month, monthly_units DESC;

-- 3. Current stock compared with lead-time demand
-- This is a basic screen; add safety stock and validate business rules.
WITH demand AS (
    SELECT product_id, AVG(daily_total) AS avg_daily_demand
    FROM (
        SELECT product_id, date, SUM(quantity_sold) AS daily_total
        FROM daily_sales
        GROUP BY product_id, date
    )
    GROUP BY product_id
)
SELECT p.product_name, i.current_stock, i.reorder_lead_time_days,
       ROUND(d.avg_daily_demand, 2) AS avg_daily_demand,
       ROUND(d.avg_daily_demand * i.reorder_lead_time_days, 2) AS lead_time_demand
FROM products p
JOIN inventory i ON p.product_id = i.product_id
JOIN demand d ON p.product_id = d.product_id
WHERE i.current_stock < d.avg_daily_demand * i.reorder_lead_time_days
ORDER BY lead_time_demand DESC;

-- 4. Category-level sales value
SELECT p.category, SUM(s.quantity_sold * p.unit_price) AS sales_value
FROM products p
JOIN daily_sales s ON s.product_id = p.product_id
GROUP BY p.category
ORDER BY sales_value DESC;
